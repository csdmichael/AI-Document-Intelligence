"""
FastAPI backend for the AI Document Intelligence Tax Form Processing solution.
All Azure access uses managed identity via DefaultAzureCredential.
"""

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from azure.identity import DefaultAzureCredential
from azure.cosmos import CosmosClient
from azure.storage.blob import BlobServiceClient
from datetime import datetime, timezone
from typing import Optional

from api.config import (
    BLOB_URL, STORAGE_ACCOUNT_NAME, STORAGE_CONTAINER_NAME, COSMOS_ENDPOINT,
    COSMOS_DATABASE, COSMOS_CONTAINER, API_HOST, API_PORT,
    DOCUMENT_INTELLIGENCE_ENDPOINT, CORS_ORIGINS,
)
from api.models import (
    FieldUpdate, BulkStatusUpdate, DocumentSummary, DocumentDetail,
    ConfidenceStats, BlobFile, RetrainingStatus,
    CustomModelStatus, TrainRequest, ImageDescriptionUpdate,
)

app = FastAPI(
    title="AI Document Intelligence - Tax Form Processor",
    version="1.0.0",
    description="Parse, review, and correct tax exemption forms with AI Document Intelligence",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Shared credential and clients (initialized lazily)
_credential = None
_cosmos_client = None
_blob_client = None


def get_credential():
    global _credential
    if _credential is None:
        _credential = DefaultAzureCredential()
    return _credential


def get_cosmos_container():
    global _cosmos_client
    if _cosmos_client is None:
        _cosmos_client = CosmosClient(url=COSMOS_ENDPOINT, credential=get_credential())
    db = _cosmos_client.get_database_client(COSMOS_DATABASE)
    return db.get_container_client(COSMOS_CONTAINER)


def get_blob_container():
    global _blob_client
    if _blob_client is None:
        _blob_client = BlobServiceClient(account_url=BLOB_URL, credential=get_credential())
    return _blob_client.get_container_client(STORAGE_CONTAINER_NAME)


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

@app.get("/health")
def health():
    return {"status": "healthy"}


# ---------------------------------------------------------------------------
# Blob Storage Endpoints (unparsed documents)
# ---------------------------------------------------------------------------

_MIME_TYPES: dict[str, str] = {
    ".pdf": "application/pdf",
    ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
}

_INLINE_TYPES = {".pdf"}


def _get_mime_type(name: str) -> str | None:
    """Return the MIME type for a supported document extension, or None."""
    ext = "." + name.rsplit(".", 1)[-1].lower() if "." in name else ""
    return _MIME_TYPES.get(ext)


# ---------------------------------------------------------------------------
# Blob Storage Endpoints (unparsed documents)
# ---------------------------------------------------------------------------

@app.get("/api/blobs", response_model=list[BlobFile])
def list_blobs():
    """List all PDF and PPTX files in the tax-forms blob container."""
    container = get_blob_container()
    blobs = []
    for b in container.list_blobs():
        content_type = _get_mime_type(b.name)
        if not content_type:
            continue
        blobs.append(BlobFile(
            name=b.name,
            size=b.size or 0,
            lastModified=b.last_modified.isoformat() if b.last_modified else "",
            url=f"{BLOB_URL}/{STORAGE_CONTAINER_NAME}/{b.name}",
            contentType=content_type,
        ))
    return blobs


@app.get("/api/blobs/{blob_name:path}")
def get_blob_content(blob_name: str):
    """Proxy a blob's content for viewing/downloading in the browser."""
    container = get_blob_container()
    try:
        blob_client = container.get_blob_client(blob_name)
        stream = blob_client.download_blob()
        media_type = _get_mime_type(blob_name) or "application/octet-stream"
        ext = "." + blob_name.rsplit(".", 1)[-1].lower() if "." in blob_name else ""
        disposition = (
            f'inline; filename="{blob_name}"'
            if ext in _INLINE_TYPES
            else f'attachment; filename="{blob_name}"'
        )
        return StreamingResponse(
            stream.chunks(),
            media_type=media_type,
            headers={
                "Content-Disposition": disposition,
                "Cache-Control": "public, max-age=3600",
            },
        )
    except Exception:
        raise HTTPException(status_code=404, detail=f"Blob '{blob_name}' not found")


@app.get("/api/blobs/{blob_name:path}/sas-url")
def get_blob_sas_url(blob_name: str):
    """Generate a temporary SAS URL for viewing a blob (e.g. via Office Online)."""
    from azure.storage.blob import generate_blob_sas, BlobSasPermissions
    from datetime import timedelta

    try:
        blob_service = get_blob_container().get_blob_client(blob_name)
        # Verify blob exists
        blob_service.get_blob_properties()
    except Exception:
        raise HTTPException(status_code=404, detail=f"Blob '{blob_name}' not found")

    try:
        svc = BlobServiceClient(account_url=BLOB_URL, credential=get_credential())
        udk = svc.get_user_delegation_key(
            key_start_time=datetime.now(timezone.utc),
            key_expiry_time=datetime.now(timezone.utc) + timedelta(hours=1),
        )
        sas_token = generate_blob_sas(
            account_name=STORAGE_ACCOUNT_NAME,
            container_name=STORAGE_CONTAINER_NAME,
            blob_name=blob_name,
            user_delegation_key=udk,
            permission=BlobSasPermissions(read=True),
            expiry=datetime.now(timezone.utc) + timedelta(hours=1),
        )
        sas_url = f"{BLOB_URL}/{STORAGE_CONTAINER_NAME}/{blob_name}?{sas_token}"
        return {"url": sas_url}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to generate SAS URL: {exc}")


# ---------------------------------------------------------------------------
# Parsed Documents Endpoints
# ---------------------------------------------------------------------------

@app.get("/api/documents", response_model=list[DocumentSummary])
def list_documents(
    category: Optional[str] = Query(None, description="Filter by confidence category: Blue|Green|Yellow|Red"),
    state: Optional[str] = Query(None, description="Filter by state abbreviation"),
    status: Optional[str] = Query(None, description="Filter by status: pending|parsed|reviewed|approved"),
    reviewed: Optional[bool] = Query(None, description="Filter by reviewed (true) or not reviewed (false)"),
    document_type: Optional[str] = Query(None, description="Filter by document type: pdf|pptx"),
):
    """List all parsed documents with optional filters."""
    container = get_cosmos_container()

    conditions = []
    params = []
    if category:
        conditions.append("c.confidenceCategory = @category")
        params.append({"name": "@category", "value": category})
    if state:
        conditions.append("c.state = @state")
        params.append({"name": "@state", "value": state.upper()})
    if status:
        conditions.append("c.status = @status")
        params.append({"name": "@status", "value": status})
    if reviewed is True:
        conditions.append("(c.status = 'reviewed' OR c.status = 'approved')")
    elif reviewed is False:
        conditions.append("(c.status != 'reviewed' AND c.status != 'approved')")
    if document_type:
        if document_type.lower() == "pdf":
            # PDFs may have documentType="pdf" or the field may be absent (legacy records
            # parsed before documentType was introduced).
            conditions.append("(c.documentType = @docType OR NOT IS_DEFINED(c.documentType))")
        else:
            # PPTX (and any future types) are new — all records will have documentType set.
            conditions.append("c.documentType = @docType")
        params.append({"name": "@docType", "value": document_type.lower()})

    where_clause = " AND ".join(conditions)
    query = "SELECT c.id, c.fileName, c.state, c.stateName, c.status, " \
            "c.overallConfidence, c.confidenceCategory, c.totalSections, " \
            "c.totalFields, c.parsedAt, c.documentType FROM c"
    if where_clause:
        query += f" WHERE {where_clause}"
    query += " ORDER BY c.overallConfidence ASC"

    items = list(container.query_items(query=query, parameters=params or None, enable_cross_partition_query=True))

    # Deduplicate: keep only the latest parsed record per fileName
    latest = {}
    for item in items:
        fn = item.get("fileName", "")
        existing = latest.get(fn)
        if not existing or (item.get("parsedAt") or "") > (existing.get("parsedAt") or ""):
            latest[fn] = item
    return list(latest.values())


@app.get("/api/documents/stats", response_model=ConfidenceStats)
def get_confidence_stats():
    """Get document count per confidence category (deduplicated by fileName)."""
    container = get_cosmos_container()
    query = "SELECT c.fileName, c.confidenceCategory, c.parsedAt FROM c"
    items = list(container.query_items(query=query, enable_cross_partition_query=True))

    # Deduplicate: keep only the latest per fileName
    latest = {}
    for item in items:
        fn = item.get("fileName", "")
        existing = latest.get(fn)
        if not existing or (item.get("parsedAt") or "") > (existing.get("parsedAt") or ""):
            latest[fn] = item

    stats = ConfidenceStats()
    for item in latest.values():
        cat_lower = (item.get("confidenceCategory") or "").lower()
        if cat_lower == "blue":
            stats.blue += 1
        elif cat_lower == "green":
            stats.green += 1
        elif cat_lower == "yellow":
            stats.yellow += 1
        elif cat_lower == "red":
            stats.red += 1
    stats.total = stats.blue + stats.green + stats.yellow + stats.red
    return stats


@app.get("/api/documents/{document_id}", response_model=DocumentDetail)
def get_document(document_id: str):
    """Get a single parsed document with all sections and fields."""
    container = get_cosmos_container()
    query = "SELECT * FROM c WHERE c.id = @id"
    params = [{"name": "@id", "value": document_id}]
    items = list(container.query_items(query=query, parameters=params, enable_cross_partition_query=True))

    if not items:
        raise HTTPException(status_code=404, detail="Document not found")
    return items[0]


@app.put("/api/documents/{document_id}/sections/{section_index}/fields/{field_name}")
def update_field(document_id: str, section_index: int, field_name: str, update: FieldUpdate):
    """
    Update a field's corrected value (human-in-the-loop correction).
    This stores the correction alongside the original extracted value.
    """
    container = get_cosmos_container()

    # Find the document
    query = "SELECT * FROM c WHERE c.id = @id"
    params = [{"name": "@id", "value": document_id}]
    items = list(container.query_items(query=query, parameters=params, enable_cross_partition_query=True))

    if not items:
        raise HTTPException(status_code=404, detail="Document not found")

    doc = items[0]

    # Find the section
    section = None
    for s in doc.get("sections", []):
        if s.get("sectionIndex") == section_index:
            section = s
            break

    if not section:
        raise HTTPException(status_code=404, detail=f"Section index {section_index} not found")

    # Find and update the field
    field_found = False
    for field in section.get("fields", []):
        if field.get("fieldName") == field_name:
            field["correctedValue"] = update.correctedValue
            field["correctedBy"] = update.correctedBy
            field["correctedAt"] = datetime.now(timezone.utc).isoformat()
            field_found = True
            break

    if not field_found:
        raise HTTPException(status_code=404, detail=f"Field '{field_name}' not found in section")

    # Update document status
    doc["status"] = "reviewed"
    doc["reviewedBy"] = update.correctedBy
    doc["reviewedAt"] = datetime.now(timezone.utc).isoformat()

    # Upsert back to Cosmos DB
    container.upsert_item(doc)

    return {"message": "Field updated", "documentId": document_id, "field": field_name}


@app.put("/api/documents/{document_id}/sections/{section_index}/images/{figure_name}")
def update_image_description(document_id: str, section_index: int, figure_name: str, update: ImageDescriptionUpdate):
    """
    Update an image description's corrected value (human-in-the-loop correction).
    Stores the correction alongside the original extracted description.
    """
    container = get_cosmos_container()

    query = "SELECT * FROM c WHERE c.id = @id"
    params = [{"name": "@id", "value": document_id}]
    items = list(container.query_items(query=query, parameters=params, enable_cross_partition_query=True))

    if not items:
        raise HTTPException(status_code=404, detail="Document not found")

    doc = items[0]

    section = None
    for s in doc.get("sections", []):
        if s.get("sectionIndex") == section_index:
            section = s
            break

    if not section:
        raise HTTPException(status_code=404, detail=f"Section index {section_index} not found")

    image_found = False
    for img in section.get("imageDescriptions", []):
        if img.get("figureName") == figure_name:
            img["correctedDescription"] = update.correctedDescription
            img["correctedBy"] = update.correctedBy
            img["correctedAt"] = datetime.now(timezone.utc).isoformat()
            image_found = True
            break

    if not image_found:
        raise HTTPException(status_code=404, detail=f"Image '{figure_name}' not found in section")

    doc["status"] = "reviewed"
    doc["reviewedBy"] = update.correctedBy
    doc["reviewedAt"] = datetime.now(timezone.utc).isoformat()

    container.upsert_item(doc)

    return {"message": "Image description updated", "documentId": document_id, "figureName": figure_name}


@app.put("/api/documents/bulk-status")
def bulk_update_status(update: BulkStatusUpdate):
    """Update the status of multiple documents at once."""
    if update.status not in ("reviewed", "approved"):
        raise HTTPException(status_code=400, detail="Status must be 'reviewed' or 'approved'")
    if not update.documentIds:
        raise HTTPException(status_code=400, detail="documentIds must not be empty")

    container = get_cosmos_container()
    updated = []
    not_found = []
    now = datetime.now(timezone.utc).isoformat()

    for doc_id in update.documentIds:
        query = "SELECT * FROM c WHERE c.id = @id"
        params = [{"name": "@id", "value": doc_id}]
        items = list(container.query_items(query=query, parameters=params, enable_cross_partition_query=True))
        if not items:
            not_found.append(doc_id)
            continue
        doc = items[0]
        doc["status"] = update.status
        if update.status == "reviewed":
            doc["reviewedBy"] = update.updatedBy
            doc["reviewedAt"] = now
        else:
            doc["approvedBy"] = update.updatedBy
            doc["approvedAt"] = now
        container.upsert_item(doc)
        updated.append(doc_id)

    return {"updated": updated, "notFound": not_found}


@app.put("/api/documents/{document_id}/approve")
def approve_document(document_id: str, approved_by: str = Query(...)):
    """Mark a document as approved after human review."""
    container = get_cosmos_container()
    query = "SELECT * FROM c WHERE c.id = @id"
    params = [{"name": "@id", "value": document_id}]
    items = list(container.query_items(query=query, parameters=params, enable_cross_partition_query=True))

    if not items:
        raise HTTPException(status_code=404, detail="Document not found")

    doc = items[0]
    doc["status"] = "approved"
    doc["approvedBy"] = approved_by
    doc["approvedAt"] = datetime.now(timezone.utc).isoformat()
    container.upsert_item(doc)

    return {"message": "Document approved", "documentId": document_id}


# ---------------------------------------------------------------------------
# Retraining — Export reviewed docs for model fine-tuning
# ---------------------------------------------------------------------------

@app.get("/api/retraining/stats", response_model=RetrainingStatus)
def get_retraining_stats():
    """Get counts of reviewed/approved documents available for retraining."""
    container = get_cosmos_container()
    query = "SELECT VALUE c.status FROM c"
    statuses = list(container.query_items(query=query, enable_cross_partition_query=True))

    reviewed = sum(1 for s in statuses if s in ("reviewed", "approved"))
    total_corrections = 0
    if reviewed > 0:
        corr_query = "SELECT VALUE c.sections FROM c WHERE c.status IN ('reviewed', 'approved')"
        sections_list = list(container.query_items(query=corr_query, enable_cross_partition_query=True))
        for sections in sections_list:
            for section in sections:
                for field in section.get("fields", []):
                    if field.get("correctedValue"):
                        total_corrections += 1

    return RetrainingStatus(
        reviewedDocuments=reviewed,
        totalDocuments=len(statuses),
        totalCorrections=total_corrections,
        readyForTraining=reviewed >= 5,
        minimumRequired=5,
    )


@app.post("/api/retraining/export")
def export_training_data():
    """Export reviewed documents with corrections as labeled training data."""
    container = get_cosmos_container()
    query = "SELECT * FROM c WHERE c.status IN ('reviewed', 'approved')"
    docs = list(container.query_items(query=query, enable_cross_partition_query=True))

    training_data = []
    for doc in docs:
        labeled_fields = []
        for section in doc.get("sections", []):
            for field in section.get("fields", []):
                labeled_fields.append({
                    "fieldName": field.get("fieldName"),
                    "extractedValue": field.get("extractedValue"),
                    "groundTruth": field.get("correctedValue") or field.get("extractedValue"),
                    "wasCorrected": field.get("correctedValue") is not None,
                    "originalConfidence": field.get("confidence"),
                })
        training_data.append({
            "documentId": doc.get("id"),
            "fileName": doc.get("fileName"),
            "state": doc.get("state"),
            "blobUrl": doc.get("blobUrl"),
            "fields": labeled_fields,
        })

    return {
        "exportedAt": datetime.now(timezone.utc).isoformat(),
        "documentCount": len(training_data),
        "documents": training_data,
    }


# ---------------------------------------------------------------------------
# Custom Model Management
# ---------------------------------------------------------------------------

def _get_di_client():
    """Return a lazy DocumentIntelligenceClient."""
    from azure.ai.documentintelligence import DocumentIntelligenceClient as _DI
    return _DI(endpoint=DOCUMENT_INTELLIGENCE_ENDPOINT, credential=get_credential())


@app.get("/api/custom-model/status", response_model=CustomModelStatus)
def get_custom_model_status():
    """Return the current custom model availability and training readiness."""
    from config import cfg as _cfg

    custom_model_id = _cfg.custom_model_id or ""
    primary_model_id = _cfg.doc_intelligence.model.model_id
    comparison_model_id = _cfg.comparison_model_id
    min_docs = _cfg.doc_intelligence.retraining.min_samples_per_type

    # Count reviewed documents
    container = get_cosmos_container()
    query = (
        "SELECT VALUE COUNT(1) FROM c "
        "WHERE c.status IN ('reviewed', 'approved')"
    )
    result = list(container.query_items(query=query, enable_cross_partition_query=True))
    reviewed_count = result[0] if result else 0

    # Verify that the custom model actually exists in Document Intelligence
    is_available = False
    if custom_model_id:
        try:
            di = _get_di_client()
            di.get_document_model(custom_model_id)
            is_available = True
        except Exception:
            is_available = False

    return CustomModelStatus(
        customModelId=custom_model_id,
        isAvailable=is_available,
        primaryModelId=primary_model_id,
        comparisonModelId=comparison_model_id,
        minimumReviewedDocs=min_docs,
        currentReviewedDocs=reviewed_count,
        readyToTrain=reviewed_count >= min_docs,
    )


@app.get("/api/custom-model/list")
def list_custom_models():
    """List all custom models available in the Document Intelligence resource."""
    try:
        di = _get_di_client()
        models = []
        for m in di.list_document_models():
            models.append({
                "modelId": m.model_id,
                "description": getattr(m, "description", ""),
                "createdDateTime": (
                    m.created_date_time.isoformat()
                    if hasattr(m, "created_date_time") and m.created_date_time
                    else None
                ),
            })
        return {"models": models, "count": len(models)}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("api.app:app", host=API_HOST, port=API_PORT, reload=True)
